
import java.sql.*; 
import java.text.ParseException; 
import java.text.SimpleDateFormat; 
import java.io.*; 
import java.lang.String; 
import java.util.Scanner; 

public class Main
{

    private static String JDBC_URL = "jdbc:mysql://localhost:3306/demo"; 
    private static String USER = "root"; 
    private static String PASSWORD = "Password";

    public static void main(String[] args) throws IOException { 
        Connection myConnection = null; 
        Statement statement = null; 
        PreparedStatement preparedStatement = null;

        try{ 
            // Connects to the Database using the Database URL, Username and Password
            myConnection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD); 

            // Success Connecting to the Database
            System.out.println("Connected to database"); 
            //Creating a table in the Database that will hold the jobdata
            System.out.println("Creating table in the database..."); 
            //Creates a statement instance for sending SQL statements to the Database
            statement = myConnection.createStatement();   

            //Create Table called JOBDATA in the statement which will be sent to the Database
            // Table Format: ColumnName  datatype
            String sql = "CREATE TABLE JOBDATA " +
                "(Company VARCHAR(128), " + 
                " DC INTEGER, " + 
                " DeliveryDate INTEGER, " + 
                " VehicleReg INTEGER, " + 
                " DropNo INTEGER, " + 
                " DropReference INTEGER, " + 
                " Timeslot VARCHAR(128), " + 
                " CustomersName VARCHAR(128), " + 
                " AddressLine1 VARCHAR(128), " + 
                " AddressLine2 VARCHAR(128), " + 
                " AddressLine3 VARCHAR(128), " + 
                " AddressLine4 VARCHAR(128), " + 
                " AddressLine5 VARCHAR(128), " + 
                " Postcode VARCHAR(128), " + 
                " DeliveryInstructions VARCHAR(128), " + 
                " DropType VARCHAR(128), " + 
                " Stockcode VARCHAR(128), " + 
                " Qty INTEGER, " + 
                " StorePhoneNo VARCHAR(128), " + 
                " CustomerPhone1 VARCHAR(128), " + 
                " CustomerPhone2 VARCHAR(128), " + 
                " CustomerPhone3 VARCHAR(128), " + 
                " StoreCustomerDrop VARCHAR(128), " + 
                " GoodsDescription VARCHAR(128), " + 
                " RouteNumber VARCHAR(128), " + 
                " RouteDesc INTEGER, " + 
                " TakePhoto VARCHAR(128), " + 
                " TomTom VARCHAR(128), " + 
                " RequiresAssembly VARCHAR(128), " + 
                " ConcordeRef VARCHAR(128), " + 
                " Barcode VARCHAR(128), " + 
                " PRIMARY KEY ( Barcode ))";

            //Executes the SQL Statement
            statement.executeUpdate(sql); 
            // Table created in the databse
            System.out.println("Created table in the database..."); 
            //closing statement
            statement.close();         

            //Creating a Prepared Statement. Parameters are labeled "?"    
            String insertTableSQL = "INSERT INTO JOBDATA" 
                + "(Company, DC, DeliveryDate, VehicleReg, DropNo, DropReference, Timeslot, CustomersName, AddressLine1, AddressLine2, AddressLine3, AddressLine4, AddressLine5, Postcode, DeliveryInstructions, DropType, Stockcode, Qty, StorePhoneNo, CustomerPhone1, CustomerPhone2, CustomerPhone3, StoreCustomerDrop, GoodsDescription, RouteNumber, RouteDesc, TakePhoto, TomTom, RequiresAssembly, ConcordeRef, Barcode) VALUES" 
                + "( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"; 

            preparedStatement = myConnection.prepareStatement(insertTableSQL); 

            //Using a file input stream to retrieve information from the CSV file.
            BufferedReader reader = new BufferedReader(new FileReader("jobdata.csv")); 

            //line read from csv 
            String line = null; 
            //scanned line 
            Scanner scanner = null;

            //Ignores the first line of the CSV document that contains the Column Headings
            reader.readLine(); 

            //Reads the CSV file line by line and uploads that information to the Database

            while((line = reader.readLine()) != null){ 
                scanner = new Scanner(line); 
                scanner.useDelimiter(","); 
                while(scanner.hasNext()){ 
                    preparedStatement.setString(1, scanner.next()); // Company
                    preparedStatement.setInt(2,Integer.parseInt(scanner.next())); //DC
                    preparedStatement.setInt(3,Integer.parseInt(scanner.next())); //DeliveryDate
                    preparedStatement.setInt(4,Integer.parseInt(scanner.next())); //VehicleReg
                    preparedStatement.setInt(5,Integer.parseInt(scanner.next())); //DropNo
                    preparedStatement.setInt(6,Integer.parseInt(scanner.next())); //DropReference
                    preparedStatement.setString(7, scanner.next()); //Timeslot
                    preparedStatement.setString(8, scanner.next()); //CustomersName
                    preparedStatement.setString(9, scanner.next()); // AddressLine1
                    preparedStatement.setString(10, scanner.next()); // AddressLine2
                    preparedStatement.setString(11, scanner.next()); // AddressLine3
                    preparedStatement.setString(12, scanner.next()); // AddressLine4
                    preparedStatement.setString(13, scanner.next()); // AddressLine5 
                    preparedStatement.setString(14, scanner.next()); //Postcode
                    preparedStatement.setString(15, scanner.next()); //Delivery Instructions
                    preparedStatement.setString(16, scanner.next()); //DropType
                    preparedStatement.setString(17, scanner.next()); // Stockcode
                    preparedStatement.setInt(18,Integer.parseInt(scanner.next())); //Qty
                    preparedStatement.setString(19, scanner.next()); //StorePhoneNo
                    preparedStatement.setString(20, scanner.next()); //CustomerPhone1
                    preparedStatement.setString(21, scanner.next()); //CustomerPhone2
                    preparedStatement.setString(22, scanner.next()); //CustomerPhone3
                    preparedStatement.setString(23, scanner.next()); //StoreCutomerDrop
                    preparedStatement.setString(24, scanner.next()); //GoodsDescription
                    preparedStatement.setString(25, scanner.next()); //RouteNumber
                    preparedStatement.setInt(26,Integer.parseInt(scanner.next())); //RouteDesc
                    preparedStatement.setString(27, scanner.next()); //TakePhoto
                    preparedStatement.setString(28, scanner.next()); //TomTom
                    preparedStatement.setString(29, scanner.next()); //RequiresAssembly
                    preparedStatement.setString(30, scanner.next()); //ConcordeRef
                    preparedStatement.setString(31, scanner.next()); //Barcode

                }
                // Updates the PreparedStatement
                preparedStatement.executeUpdate(); 
            } 
            //Closes the Prepared Statement
            preparedStatement.close();
            // Message verifying Data has been successfully imported into the Databse;
            System.out.println("Data imported"); 
            //Closes the CSV Reader
            reader.close(); 

        } catch (SQLException e){ 
            e.printStackTrace(); 
        }finally{ //Closing the Connection
            try{ 
                if(statement!=null) 
                    myConnection.close(); 
            }catch(SQLException se){ 
            }// Do nothing
            try{ 
                if(myConnection!=null) 
                    myConnection.close(); 
            }catch(SQLException se){ 
                se.printStackTrace(); 
            } 
            // Message explaining connection to the Database has been closed
            System.out.println("Connection closed"); 
        } 
    } 
} 