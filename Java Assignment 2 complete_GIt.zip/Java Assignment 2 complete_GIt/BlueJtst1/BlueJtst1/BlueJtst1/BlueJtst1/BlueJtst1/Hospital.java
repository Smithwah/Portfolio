
/**
 * Write a description of class Hospital here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Hospital
{
    private ArrayList<Doctor> doctors;
    private ArrayList<Patient> patients;
    private ArrayList<Prescription> prescriptions;
    private ArrayList<PatientVisits> visits;
    private ArrayList<Outcall> outcalls;

    private Hospital hospital;
    private int nextDocNumber;
    private int nextPatientNumber;
    private int selection;
    private int choice;
    private String name;

    private String firstName;
    private String surName;
    private String address;
    private String startSurHours;
    private String endSurHours;
    private String startCallHours;
    private String endCallHours;
    private String firstChoiceDoctor;

    private String patientName;
    private String Date;
    private String Ailment;
    private String patientPrescription;
    private String doctorVisited;
    private String drugName;
    private String prescriber;
    private String patient;

    private String medications;

    private String visitingDoctor;
    private String visitedPatient ;
    private String visitDate;
    private int removalNumber;

    Scanner stdin =
        new Scanner ( System.in);

    // Application Entry Point
    public static void main (String args[])
    {

        Hospital class1 = new Hospital();
        class1.menu();
    }

    // menu method is the first called when the enry point is accessed
    public void menu()
    {

        System.out.println( "*** Patient Record System *** "); 
        System.out.println( "1 - List Doctors/Patients ");  
        System.out.println( "2 - Add Doctors/Patients "); 
        System.out.println( "3 - Remove Doctor/Patient ");
        System.out.println( "4 - List Patient Prescriptions ");
        System.out.println( "5 - List Available Doctors / Waiting Patients ");
        System.out.println( "6 - List/Add Patient Visits ");
        System.out.println( "7 - Change Doctor Call/Surgery Hours ");
        System.out.println( "8 - List/Add Outcalls Made ");   
        System.out.println( "0 - End Application ");

        //Switch case allowing user to navigate menus
        selection = stdin.nextInt();
        switch (selection)
        {
            case 1:
            listDocPat();
            break;

            case 2:
            addDocPat();
            break;

            case 3:
            removeDocPat();
            break;

            case 4: 
            listPatientPrescriptions();
            break;

            case 5 :
            availDocWaitPat();
            break;

            case 6:
            listAddPatVisit();
            break;

            case 7:
            changeHours();
            break;

            case 8:
            listAddOutcalls();
            break;

            case 0:
            System.exit(0);

            default :
            menu();

        }
    }

    // Method allowing user select to list doctors or patients
    public void listDocPat()
    {

        System.out.println( "1 - List Doctors ");  
        System.out.println( "2 - List Patients "); 

        //Switch case Taking user to the appropriate list method

        choice = stdin.nextInt();
        switch (choice)
        {
            case 1:
            System.out.print('\u000C');
            listDoctors();
            break;

            case 2:
            System.out.print('\u000C');
            listPatients();
            break;

            default:

            menu();

        }
    }

    // Method allowing user select to add doctors or patients
    public void addDocPat()
    {

        System.out.println( "1 - Add Doctor ");  
        System.out.println( "2 - Add Patient "); 

        //Switch case Taking user to the appropriate add method

        choice = stdin.nextInt();
        switch (choice)
        {
            case 1:
            System.out.print('\u000C');

            newDoctor( firstName, surName,  address,  startSurHours,  endSurHours,  startCallHours, endCallHours);
            {

            }
            break;

            case 2:
            System.out.print('\u000C');
            newPatient( firstName,surName,  address, firstChoiceDoctor, medications);
            {

            }
            break;

            default:

            menu();   

        }
    }

    // Method allowing user select to remove doctors or patients
    public void removeDocPat()
    {
        System.out.println( "1 - Remove Doctor ");  
        System.out.println( "2 - Remove Patient "); 

        //Switch case Taking user to the appropriate remove method

        choice = stdin.nextInt();
        switch (choice)
        {
            case 1:
            System.out.print('\u000C');
            removeDoctor();
            break;

            case 2:
            System.out.print('\u000C');
            removePatient();
            break;

            default:
            menu();   

        }
    }

    // Method allowing user to list the available doctors or waiting patients
    public void availDocWaitPat()
    {
        System.out.print('\u000C');
        System.out.println( "1 - List Available Doctors ");  
        System.out.println( "2 - List Waiting Patients "); 

        //Switch case Taking user to the appropriate list method

        choice = stdin.nextInt();
        switch (choice)
        {
            case 1:
            System.out.print('\u000C');
            listAvailableDoctors();
            System.out.println ( "Press Any Key To Return To The Main Menu");
            stdin.next();
            System.out.print('\u000C');
            menu();

            break;

            case 2:
            System.out.print('\u000C');
            listWaitingPatients();
            System.out.println ( "Press Any Key To Return To The Main Menu");
            stdin.next();
            System.out.print('\u000C');
            menu();

            break;

            default:
            menu();   

        }

    }

    // Method allowing user to list or add patient visits
    public void listAddPatVisit()
    {
        System.out.println( "1 - List Patient Surgery Visits ");  
        System.out.println( "2 - Add Patient Surgery Visit "); 

        //Switch case Taking user to the appropriate  method

        choice = stdin.nextInt();
        switch (choice)
        {
            case 1:
            System.out.print('\u000C');
            listPatientVisits();
            break;

            case 2:
            System.out.print('\u000C');
            newPatientVisit(patientName, Date, Ailment, patientPrescription, doctorVisited);
            {

            }

            break;

            default:
            menu();   

        }   

    }

    // Method allowing user to change the on call and surgery hours of the doctor
    public void changeHours()
    {

        System.out.println( "1 - Change Doctor Call Hours ");  
        System.out.println( "2 - Change Doctor Surgery Hours ");

        choice = stdin.nextInt();
        switch (choice)
        {
            case 1:
            System.out.print('\u000C');
            changeCallHours();
            break;

            case 2:
            System.out.print('\u000C');
            changeSurHours();

            break;

            default:
            menu(); 

        }
    }

    // Method allowing user to list the outcalls or add one to the system
    public void listAddOutcalls()
    {
        System.out.println( "1 - Add A Doctor Outcall To The System ");  
        System.out.println( "2 - List The Outcalls Made By Doctors ");

        choice = stdin.nextInt();
        switch (choice)
        {
            case 1:
            System.out.print('\u000C');
            listOutcalls();
            break;

            case 2:
            System.out.print('\u000C');
            newOutcall( visitingDoctor, visitedPatient,  visitDate);
            {

            }

            break;
            default:
            menu(); 

        }

    }

    // % array lists are created with hardcoded data, these list can be added to and removed from by the user of the system
    public Hospital()
    {
        doctors = new ArrayList<Doctor>();

        doctors.add(new Doctor("Toby" ,"Jones", "812 Pleasant Ave", "9" , "5", "11", "4", false));
        doctors.add(new Doctor( "Sarah", "Reed", "74 Tithebarn Street", "11", "3", "6", "12", true));
        doctors.add(new Doctor( "Harry","Wright", "21 Dale Street", "8", "1", "3", "1", false));
        doctors.add(new Doctor( "Emily","Buckley", "461 Oldburn Road", "10", "6", "10", "2", true));

        patients = new ArrayList<Patient>();

        patients.add(new Patient( "Hannah","Atkins", "32 Calcaria Street", doctors.get(3).getFullName() , true));
        patients.add(new Patient( "Robert","Westley", "120 Stutton Road", doctors.get(0).getFullName(), false));
        patients.add(new Patient( "Emma","Green", "632 Main Street", doctors.get(1).getFullName(), true));
        patients.add(new Patient("Charlie","Ingham", "493 Woodlands Ave", doctors.get(2).getFullName(), false));

        prescriptions = new ArrayList<Prescription>();

        prescriptions.add(new Prescription("Paracetamol", "Sarah Reed", "Emma Green"));
        prescriptions.add(new Prescription("Ibuprofen", "Harry Wright", "Charlie Ingham"));
        prescriptions.add(new Prescription("Aspirin", "Emily Buckley", "Hannah Atkins"));
        prescriptions.add(new Prescription("Calpol", "Toby Jones", "Robert Wesley"));

        visits = new ArrayList<PatientVisits>();
        visits.add(new PatientVisits(patients.get(2).getFullName(), "07/12/16", "Headache","Paracetamol", doctors.get(0).getFullName() ));
        visits.add(new PatientVisits(patients.get(3).getFullName(), "12/10/16", "Sore Throat", "Ibuprofen", doctors.get(1).getFullName()));
        visits.add(new PatientVisits(patients.get(0).getFullName(), "05/11/16", "Fever", "Aspirin", doctors.get(2).getFullName()));
        visits.add(new PatientVisits(patients.get(1).getFullName(), "23/08/16", "Stomach Ache", "Calpol", doctors.get(3).getFullName()));

        outcalls = new ArrayList<Outcall>();
        outcalls.add(new Outcall (doctors.get(0).getFullName(), patients.get(2).getFullName(), "01/12/16"));
        outcalls.add(new Outcall (doctors.get(1).getFullName(), patients.get(1).getFullName(), "07/06/16" ));
        outcalls.add(new Outcall (doctors.get(3).getFullName(), patients.get(3).getFullName(), "23/12/16" ));
        outcalls.add(new Outcall (doctors.get(0).getFullName(), patients.get(0).getFullName(),"16/07/16" ));

    }

    //Method to change the call hours of the doctor.
    public void changeCallHours()
    {
        System.out.println ( "Please Enter The Number Of Doctor Whose Call Hours You Wish To Change");
        removalNumber = stdin.nextInt();

        if (removalNumber > doctors.size()){
            System.out.println ( "Doctor Number Does Not Exist");

        }

        else
        {
            System.out.println ( "Enter New Start Call Hour For Doctor (am)");
            doctors.get(removalNumber-1).setSCHours();
            System.out.println ( "Enter New End Call Hour For Doctor (pm)");
            doctors.get(removalNumber-1).setECHours();
            System.out.println ( "Doctor Call Hours Altered");
        }

        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();
    }
    //Method to change the surgery hours of the doctor.
    public void changeSurHours()
    {
        System.out.println ( "Please Enter The Number Of Doctor Whose Surgery Hours You Wish To Change");
        removalNumber = stdin.nextInt();

        if (removalNumber > doctors.size())
        {
            System.out.println ( "Doctor Number Does Not Exist");

        }

        else
        {
            System.out.println ( "Enter New Start Surgery Hour For Doctor (am)");
            doctors.get(removalNumber-1).setSSHours();   
            System.out.println ( "Enter New End Surgery Hour For Doctor (pm)");
            doctors.get(removalNumber-1).setESHours();
            System.out.println ( "Doctor Surgery Hours Altered");

        }
        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();

    }
    //Method to list the doctors
    public void listDoctors()
    {
        for(int index = 0; index < doctors.size(); index++) {
            Doctor doctor = (Doctor)doctors.get(index);
            doctor.print();
            System.out.println();

        }

        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();

    }
    //Method to change the outcalls
    public void listOutcalls()
    {
        for(int index = 0; index < outcalls.size(); index++) {
            Outcall outcall = (Outcall)outcalls.get(index);
            outcall.print();
            System.out.println();

        }

        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();

    }
    //Method to change the patients
    public void listPatients()
    {
        for(int index = 0; index < patients.size(); index++) {
            Patient patient = (Patient)patients.get(index);
            patient.print();
            System.out.println();

        }

        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();
    }
    //Method to list the patient visits
    public void listPatientVisits()
    {
        for(int index = 0; index < visits.size(); index++) {
            PatientVisits visit = (PatientVisits)visits.get(index);
            visit.print();
            System.out.println();
        }
        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();

    }
    //Method to add a new patient visit to the system
    public void newPatientVisit(String patientName, String Date, String Ailment, String patientPrescription, String doctorVisited)
    {
        System.out.println( "Enter Visiting Patient Name ");
        patientName = stdin.next();
        System.out.println( "Enter The Date Of The Patient Visit eg. (01/01/16) ");
        Date = stdin.next();
        System.out.println( "Enter The Illness of the Patient ");
        Ailment = stdin.next();
        System.out.println( "Enter The Drugs Prescribed To The Patient ");
        patientPrescription = stdin.next();
        System.out.println( "Enter The Name Of The Visited Doctor ");
        doctorVisited = stdin.next();

        System.out.println ("Patient: " + patientName + " " + "Visit Has Been Added To The System");
        visits.add(new PatientVisits(patientName, Date, Ailment, patientPrescription, doctorVisited));

        System.out.println( "Was A New Patient Prescription Administered? "); 
        System.out.println( "1 - Yes ");  
        System.out.println( "2 - No "); 

        choice = stdin.nextInt();
        switch (choice)
        {
            case 1:
            System.out.print('\u000C');
            System.out.println( "Please Add The Prescription To The Database "); 
            newPrescription( drugName, prescriber, patient);
            {

            }

            break;

            case 2:
            System.out.print('\u000C');
            menu();

            break;

            default:
            menu();   

        }   

        /*
        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();
         */
    }
    //Method to add a new doctor to the system
    public void newDoctor(String firstName,String surName, String address, String startSurHours, String endSurHours, String startCallHours, String endCallHours)
    {

        System.out.println( "Enter Doctor First Name ");
        firstName = stdin.next();
        System.out.println( "Enter Doctor Surname ");
        surName = stdin.next();
        System.out.println( "Enter Doctor Address ");
        address = stdin.next();
        System.out.println( "Enter Doctor Start Surgery Hours (am) ");
        startSurHours = stdin.next();
        System.out.println( "Enter Doctor End Surgery Hours (pm) ");
        endSurHours = stdin.next();
        System.out.println( "Enter Doctor Start Call Hours (am) ");
        startCallHours = stdin.next();
        System.out.println( "Enter Doctor End Call Hours (pm) ");
        endCallHours = stdin.next();

        System.out.println ("New Doctor : " + firstName + " " + surName + " " + "Has Been Added To The System");

        doctors.add(new Doctor(firstName,surName, address, startSurHours, endSurHours, startCallHours, endCallHours, true));

        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();

    }
    //Method to list Patient Prescriptions
    public void listPatientPrescriptions()
    {

        System.out.print('\u000C');

        for(int index = 0; index < prescriptions.size(); index++) {
            Prescription prescription = (Prescription)prescriptions.get(index);
            prescription.print();
            System.out.println();

        }

        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();
    }
    //Method to add a new patient to the system
    public void newPatient(String firstName,String surName, String address,String firstChoiceDoctor, String medications)
    {
        System.out.println( "Enter Patient First Name ");
        firstName = stdin.next();
        System.out.println( "Enter Patient Surname ");
        surName = stdin.next();
        System.out.println( "Enter Patient Address ");
        address = stdin.next();
        System.out.println( "Enter Patient First Choice Doctor ");
        firstChoiceDoctor = stdin.next();

        System.out.println ("New Patient : " + firstName + " " + surName + " " + "Has Been Added To The System");
        patients.add(new Patient( firstName,surName, address, firstChoiceDoctor, true));

        System.out.println( "");

        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();

    }
    //Method to add a new prescription to the system
    public void newPrescription(String drugName, String prescriber, String patient)
    {
        System.out.println( "Enter Drug Administered ");
        drugName = stdin.next();
        System.out.println( "Enter Doctor That Prescribed The Medication ");
        prescriber = stdin.next();
        System.out.println( "Enter The Patient To Whom The Drug Was Administered  ");
        patient = stdin.next();

        prescriptions.add(new Prescription(drugName, prescriber, patient));

        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();

    }
    //Method to add a new outcall to the system
    public void newOutcall(String visitingDoctor, String visitedPatient, String visitDate)
    {
        System.out.println( "Enter The Name Of The Doctor That Made The Outcall ");
        visitingDoctor = stdin.next();
        System.out.println( "Enter The Name Of The Patient That Was Visited ");
        visitedPatient = stdin.next();
        System.out.println( "Enter The Date That The Outcall Was Made e.g.(01,01,94)  ");
        visitDate = stdin.next();

        outcalls.add(new Outcall(visitingDoctor, visitedPatient, visitDate));

        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();

    }
    //Method to list patients waiting to be seen
    public void listWaitingPatients()
    {
        for (Patient selection : patients) {

            for(int index = 0; index < prescriptions.size(); index++) {
                Patient patient = (Patient)patients.get(index);
                if (patient.getWaiting() == true){
                    patient.printWaiting();
                    System.out.println();

                }

            }
            return;
        }

        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();
    }
    //Method to list the doctors available
    public void listAvailableDoctors()
    {
        for (Doctor selection : doctors) {

            for(int index = 0; index < doctors.size(); index++) {
                Doctor doctor = (Doctor)doctors.get(index);
                if (doctor.getWaiting() == true){
                    doctor.printWaiting();
                    System.out.println();

                }

            }
            return;
        }
        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();
        return;
    }
    //Method to remove doctor from system
    public  void removeDoctor ()
    {

        System.out.println ( "Please Enter The Number Of Doctor That You wish To Remove");
        removalNumber = stdin.nextInt();

        if (removalNumber > doctors.size()){
            System.out.println ( "Doctor Number Does Not Exist");

        }

        else
        {
            System.out.println ( "Doctor Has Been Removed From System");
            doctors.remove(removalNumber-1);
        }

        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();
        return;

        /*
        for (Doctor selection : doctors) {
        if (selection.getFirstName() == firstName) {
        doctors.remove(selection);
        System.out.println( "Doctor Has Been Removed ");
        break;
        }
        }

        System.out.println( "Doctor Name :" + firstName + "  Does not exist");
         */
    }
    //Method to remove patient from system
    public void removePatient()
    {
        System.out.println ( "Please Enter The Number Of Doctor That You wish To Remove");
        removalNumber = stdin.nextInt();

        if (removalNumber > patients.size()){
            System.out.println ( "Patient Number Does Not Exist");

        }

        else
        {
            System.out.println ( "Patient Has Been Removed From System");
            patients.remove(removalNumber-1);
        }

        System.out.println ( "Press Any Key To Return To The Main Menu");
        stdin.next();
        System.out.print('\u000C');
        menu();
        return;
    }
}
