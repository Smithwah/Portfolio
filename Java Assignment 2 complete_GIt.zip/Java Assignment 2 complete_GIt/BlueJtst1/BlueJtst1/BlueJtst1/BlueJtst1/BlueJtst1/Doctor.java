
/**
 * Write a description of class Doctor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.util.Scanner;
import java.util.List;

public class Doctor
{

    Scanner stdin = new Scanner( System.in);

    private int number;
    private String name;
    private String address;
    private String startSurHours;
    private String endSurHours;
    private String startCallHours;
    private String endCallHours;
    private String firstName;
    private String surName;
    private String newName;
    private boolean isWaiting;

    public Doctor(String firstName,String surName, String address, String startSurHours, String endSurHours, String startCallHours, String endCallHours, Boolean isWaiting )
    {
        this.number = number;
        this.name = name;
        this.address = address;
        this.startSurHours = startSurHours;
        this.endSurHours = endSurHours;
        this.startCallHours = startCallHours;
        this.endCallHours = endCallHours;

        this.surName = surName;
        this.firstName = firstName;

        this.isWaiting = isWaiting;

    }

    //Print Method For The Doctor Class
    public void print()
    {
        System.out.println("Doctor Name: " + firstName + " " + surName);
        System.out.println("Doctor Address: " + address);
        System.out.println("Surgeory hours between: " + startSurHours + "am" + " - " + endSurHours + "pm" );
        System.out.println("On Call hours between: " + startCallHours + "am" + " - " + endCallHours + "pm" );

    }

    // Getter For The Doctors Firstname 
    public String getFirstName()
    {
        return firstName;

    }

    //Getter for The Doctors Surname
    public String getsurName()
    {
        return surName;

    }

    //Getter For The Doctors Full Name
    public String getFullName()
    {
        return firstName + " " + surName;

    }

    //Print Waiting Method For The Doctor Class
    public void printWaiting()
    {
        System.out.println("Doctor Name: " + firstName + " " + surName);
        System.out.println("Is Currently Available To See Patients");

    }
    //Getter For The Doctors Full Name
    public boolean getWaiting()
    {
        return isWaiting;
    }

    // Setter to change doctor  Start Call Hours
    public void setSCHours()
    {
        this.startCallHours = stdin.next();
    }

    //Setter to change the doctors End Call Hours
    public void setECHours()
    {
        this.endCallHours = stdin.next();
    }

    //Setter to change the doctors start surgery Hours
    public void setSSHours()
    {
        this.startSurHours = stdin.next();
    }

    ////Setter to change the doctors End surgery Hours
    public void setESHours()
    {
        this.endSurHours = stdin.next();
    }

}
