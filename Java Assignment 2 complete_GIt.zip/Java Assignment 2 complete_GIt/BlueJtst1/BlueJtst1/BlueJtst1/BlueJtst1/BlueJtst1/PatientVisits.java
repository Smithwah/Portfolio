
/**
 * Write a description of class Patient_Visits here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

//List of Individual patient visits to the surgery with date and type of ailment
//List of All patient visits to the surgery with date and type of ailment
// Administrator can add latest visits

public class PatientVisits
{

    // date of visit
    private String Date;
    // Pateint illness
    private String Ailment;
    // Patient Name
    private String patientName;
    // Medicine provided
    private String patientPrescription;

    // Doctor visited
    private String doctorVisited;

    public PatientVisits (String patientName, String Date, String Ailment, String patientPrescription, String doctorVisited)
    {
        this.Date = Date;
        this.Ailment = Ailment;
        this.patientName = patientName;
        this.patientPrescription = patientPrescription;
        this.doctorVisited = doctorVisited;

    }

    
    //Print Method For The PatientVisits Class
    public void print()
    {
        System.out.println("Patient: " + patientName);
        System.out.println("Visited the surgery on: " + Date);
        System.out.println("The Patient Visited: " + doctorVisited);
        System.out.println("With the ailment of: " + Ailment);
        System.out.println("Patient was prescribed: " + patientPrescription);
    }


}



