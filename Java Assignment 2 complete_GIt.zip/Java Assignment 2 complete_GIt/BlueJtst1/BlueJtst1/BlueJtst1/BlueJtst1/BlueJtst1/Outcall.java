
/**
 * Write a description of class Outcalls here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Outcall
{
    private String visitingDoctor;
    private String visitedPatient;
    private String visitDate;

    public Outcall ( String visitingDoctor, String visitedPatient, String visitDate)
    {
        this.visitingDoctor = visitingDoctor;
        this.visitedPatient = visitedPatient;
        this.visitDate = visitDate;

    }

    //Print Method For The Outcall Class
    public void print()
    {
        System.out.println("Doctor: " + visitingDoctor);
        System.out.println("Made An Outcall On The: " + visitDate);
        System.out.println("To Patient: " + visitedPatient);

    }

    
}
