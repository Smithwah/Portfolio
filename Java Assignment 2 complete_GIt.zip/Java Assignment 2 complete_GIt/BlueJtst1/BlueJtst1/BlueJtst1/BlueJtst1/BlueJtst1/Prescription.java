
/**
 * Write a description of class Drug here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Prescription
{

    private String drugName;
    private String prescriber;
    private String patient;

    public Prescription ( String drugName, String prescriber, String patient)
    {
        this.drugName = drugName;
        this.prescriber = prescriber;
        this.patient = patient;
    }

    //Print Method For The Prescription Class
    public void print()
    {
        System.out.println("Drug Prescribed: " + drugName);
        System.out.println("Drug Prescribed By Doctor: " + prescriber);
        System.out.println("Drug Prescribed To Patient: " + patient);

    }

  
    // Getter For The Patients Firstname 
    public String getPatientName()
    {
        return patient;
    }

    // Getter For The prescriber and drugname 
    public String getPatPrescription()
    {
        return  "Patient Presribed: " + drugName + " " + "By Doctor: " + prescriber;
    }

}
