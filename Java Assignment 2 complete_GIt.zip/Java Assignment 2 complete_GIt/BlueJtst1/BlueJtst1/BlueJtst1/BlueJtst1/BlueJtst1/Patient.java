
/**
 * Write a description of class Patient here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Patient
{
    private int number;

    private String name;
    private String firstName;
    private String surName;
    private String address;
    private String firstChoiceDoctor;
    private String medications;
    private boolean isWaiting;

    
    public Patient( String firstName,String surName, String address, String firstChoiceDoctor, Boolean isWaiting)
    {
        this.number = number;
        this.firstName = firstName;
        this.surName = surName;
        this.address = address;
        this.firstChoiceDoctor = firstChoiceDoctor;
        this.isWaiting = isWaiting;

        
    }

    //Print Method For The Patient Class
    public void print()
    {

        System.out.println("Patient Name: " + firstName + " " + surName);
        System.out.println("Patient Address: " + address);
        System.out.println("First Choice Doctor: " + firstChoiceDoctor);

    }

    // Getter For The Patients Firstname 
    public String getFirstName()
    {
        return firstName;

    }

    //Print Method For The Waiting Patients Class
    public void printWaiting()
    {
        System.out.println("Patient Name: " + firstName + " " + surName);
        System.out.println("Is Currently Waiting To Be Seen");

    }
    // Getter For The isWaiting Boolean 
    public boolean getWaiting()
    {
        return isWaiting;
    }

    // Getter For The Patients Fullname
    public String getFullName()
    {
        return firstName + " " + surName;

    }

   
}
