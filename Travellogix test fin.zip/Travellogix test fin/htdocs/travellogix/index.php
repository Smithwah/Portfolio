<?php

require 'config.php';

$i = 1;

while ($i ==1 ){

$sql = "LOAD DATA INFILE 'C:/xampp/htdocs/travellogix/INV.csv' REPLACE INTO TABLE invoices"
. " FIELDS TERMINATED BY ','"
. " LINES TERMINATED BY '\r\n'"
. " IGNORE 1 LINES";

//Try to execute query (not stmt) and catch mysqli error from engine and php error
if (!($stmt = $mysqli->query($sql))) {
    echo "\nQuery execute failed: ERRNO: (" . $mysqli->errno . ") " . $mysqli->error;
} else {
	echo "Data has been imported into the 'Invoices' table. <br />";
}

$i++;

}


while ($i ==2 ){

$sql = "LOAD DATA INFILE 'C:/xampp/htdocs/travellogix/HEAD.csv' REPLACE INTO TABLE head"
. " FIELDS TERMINATED BY ','"
. " LINES TERMINATED BY '\r\n'"
. " IGNORE 1 LINES";


if (!($stmt = $mysqli->query($sql))) {
    echo "\nQuery execute failed: ERRNO: (" . $mysqli->errno . ") " . $mysqli->error;
} else {
	echo"Data has been imported into the 'Head' table. <br />";
}

$i++;

}


while ($i ==3 ){

$sql = "LOAD DATA INFILE 'C:/xampp/htdocs/travellogix/AIR.csv' REPLACE INTO TABLE air"
. " FIELDS TERMINATED BY ','"
. " LINES TERMINATED BY '\r\n'"
. " IGNORE 1 LINES";

//Try to execute query (not stmt) and catch mysqli error from engine and php error
if (!($stmt = $mysqli->query($sql))) {
    echo "\nQuery execute failed: ERRNO: (" . $mysqli->errno . ") " . $mysqli->error;
} else {
	echo"Data has been imported into the 'Air' table. <br />";
}

$i++;

}


