<?php

$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "data";

$conn = mysqli_connect($dbServername,$dbUsername,$dbPassword);
mysqli_select_db($conn,'data');

if ($conn->connect_error){
	die("Connection Failed: " . $conn->connect_error);
} else{
		echo "Connected Successfully <br /> ";
	}
// PHP Script to connect to the database