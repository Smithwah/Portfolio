<?php

require 'config.php';

$sql = "UPDATE air SET acct_id = 'Replacement' ;";


if ($mysqli->query($sql) === TRUE) {
    echo "New records created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $mysqli->error;
}


