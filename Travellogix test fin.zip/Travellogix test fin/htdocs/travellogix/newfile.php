<?php



$sql = "SELECT acct_id FROM head";
$result = $mysqli->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "acct_id: " . $row["acct_id"]. "<br>";
    }
} else {
    echo "0 results";
}




//////////////////////////////////////////


$sql = "INSERT INTO air (acct_id)SELECT acct_id FROM head ;";


if ($mysqli->multi_query($sql) === TRUE) {
    echo "New records created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $mysqli->error;
}






///////////////////////////////////////



$sql = "UPDATE air P SET P.acct_id =(
SELECT acct_id
FROM head
WHERE acct_id=P.acct_id);";

//////////////////////////////////////////////


$sql = "UPDATE employee SET employee_id = 'THIS IS WHAT WILL BE REPLACED' ;";


if ($mysqli->multi_query($sql) === TRUE) {
    echo "New records created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $mysqli->error;
}



