<?php 

$mysqli  =  new mysqli('localhost','root','','data');
/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
} else {
	echo "Connected to the database successfully!! <br /> <br />  ";
}


